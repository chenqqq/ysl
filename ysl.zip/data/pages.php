<?php
require_once('init.php');
header("Content-Type:application/json;charset=utf-8");
$sql = "SELECT pid,title,fid,img,price,detail FROM ysl_product ";
$result = mysqli_query($conn,$sql);
$rows = mysqli_fetch_all($result,1);
// var_dump($rows);
echo json_encode($rows);
