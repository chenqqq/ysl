<?php
require_once('init.php');
header("Content-Type:application/json;charset=utf-8");
@$pid = $_REQUEST["pid"];
$sql = "SELECT * FROM ysl_product where pid=$pid";
$result = mysqli_query($conn,$sql);
$rows = mysqli_fetch_assoc($result);
echo json_encode($rows);

