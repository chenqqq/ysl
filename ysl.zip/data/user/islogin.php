<?php
/**
 * @Author: anchen
 * @Date:   2018-01-27 16:12:45
 * @Last Modified by:   anchen
 * @Last Modified time: 2018-01-29 20:41:09
 */
header("Content-Type:application/json");
require_once("../init.php");
session_start();
@$uid=$_SESSION["uid"];
if($uid){
    $sql="SELECT uname FROM ysl_user WHERE uid=$uid";
    $uname=mysqli_fetch_row(mysqli_query($conn,$sql))[0];
    echo json_encode(["ok"=>1,"uname"=>$uname]);
}else{
    echo json_encode(["ok"=>0]);
}