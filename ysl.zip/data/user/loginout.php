<?php
/**
 * @Author: anchen
 * @Date:   2018-01-27 15:26:04
 * @Last Modified by:   anchen
 * @Last Modified time: 2018-01-29 19:28:23
 */
/*data/user/loginout.php*/
session_start();
session_unset();
session_destroy();