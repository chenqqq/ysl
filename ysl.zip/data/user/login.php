<?php
header("Content-Type:application/json;charset=utf-8");
require_once("../init.php");
@$uname=$_REQUEST["uname"];
@$upwd=$_REQUEST["upwd"];
if($uname&&$upwd){
  $sql="SELECT uid,uname,upwd,email,phone,avatar,user_name,gender FROM  ysl_user where uname='$uname' and upwd=$upwd";
  $row=mysqli_fetch_row(mysqli_query($conn,$sql));
  if($row){
    session_start();
    $_SESSION["uid"]=$row[0];
    //var_dump($_SESSION["uid"]);
    echo json_encode(["code"=>1,"msg"=>"登录成功"]);
  }else{
    echo json_encode(["code"=>-1,"msg"=>"用户名或密码错误"]);
  }
}