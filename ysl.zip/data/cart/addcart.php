<?php
header ('Content-Type:application/json;charset=UTF-8');
require_once('../init.php');
// @$lid = $_REQUEST['lid'] or die('{"code":401,"msg":"lid required"}');
// @$buyCount = $_REQUEST['buyCount'] or die('{"code":402,"msg":"buyCount required"}');
session_start();
@$uid=$_SESSION['uid'];
if(!@$_SESSION['uid']){
    die('{"code":300, "msg":"login required"}');
}
@$product_id=$_REQUEST["product_id"];
@$count=$_REQUEST["count"];
if(@$_SESSION['uid']){
    $sql="INSERT INTO ysl_shoppingcart_item VALUES(NULL,$uid,$product_id,$count,0)";
    $result=mysqli_query($conn,$sql);
    if($result){
        echo '{"code":200,"msg":"添加成功"}';
    }else{
        echo '{"code":201,"msg":"添加失败"}';
    }
}else{
    echo '{"code":202}';
}