<?php
/**
* 获取当前登录用户的购物车内容
*/
header('Content-Type: application/json;charset=UTF-8');
require_once('../init.php');
// @$id = $_REQUEST["product_id"];
session_start();
if(! @$_SESSION['uid']){
  $_SESSION['pageToJump'] = 'cart.html';
  die('{"code":300, "msg":"login required"}');
}
$uid = $_SESSION['uid'];
$sql = "SELECT * FROM ysl_shoppingcart_item y,ysl_product p WHERE y.product_id=p.pid AND user_id = '$uid'";
$result = mysqli_query($conn, $sql); 
$list = mysqli_fetch_all($result, 1);
$output = [
  'code'=>200,
  'data'=>$list
];
echo json_encode($output);






//获取总记录数




// $sql = "SELECT pid,title,fid,img,price,detail FROM ysl_product l, ysl_shoppingcart_item s WHERE l.lid=s.product_id AND user_id=$_SESSION[loginUid]";
// $result = mysqli_query($conn, $sql);
// $list = mysqli_fetch_all($result, MYSQLI_ASSOC);
// echo json_encode($list);
?>