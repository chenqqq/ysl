<?php
/**
* 获取当前登录用户的购物车内容(已勾选条目)
*/
header('Content-Type: application/json;charset=UTF-8');

session_start();
if(! @$_SESSION['loginUid']){
  $_SESSION['pageToJump'] = 'cart.html';
  die('{"code":300, "msg":"login required"}');
}
require_once('../init.php');
//获取总记录数
$sql = "SELECT pid,title,fid,img,price,detail FROM ysl_product , ysl_shoppingcart_item s WHERE l.lid=s.product_id AND user_id=$_SESSION[loginUid] AND is_checked=1";
$result = mysqli_query($conn, $sql);
$list = mysqli_fetch_all($result, MYSQLI_ASSOC);
echo json_encode($output);