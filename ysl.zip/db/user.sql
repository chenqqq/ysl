CREATE DATABASE web1709b CHARSET=UTF8;
USE web1709b;
#用户表
CREATE TABLE t_user(
    uid INT PRIMARY KEY AUTO_INCREMENT,
    uname VARCHAR(25) NOT NULL DEFAULT '',
    upwd VARCHAR(32) NOT NULL DEFAULT ''
);
INSERT INTO t_user VALUES(null,'tom','123');
INSERT INTO t_user VALUES(null,'jerry','123');
#角色表
CREATE TABLE t_role(
    rid INT PRIMARY KEY AUTO_INCREMENT,
    rname VARCHAR(50) NOT NULL DEFAULT ''
);
INSERT INTO t_role VALUES(null,'超级管理员');
INSERT INTO t_role VALUES(null,'订单操作员');
#用户与角色关系表
CREATE TABLE t_user_role(
    id INT PRIMARY KEY AUTO_INCREMENT,
    uid INT NOT NUll DEFAULT 0,
    rid INT NOT NUll DEFAULT 0
    #FOREIGN KEY(uid) REFERENCES t_user(uid),
    #FOREIGN KEY(rid) REFERENCES t_role(rid)
);
INSERT INTO t_user_role VALUES(null,1,1);
INSERT INTO t_user_role VALUES(null,2,1);
#模块表
CREATE TABLE t_module(
    mid INT PRIMARY KEY AUTO_INCREMENT,
    mname VARCHAR(100) NOT NULL DEFAULT '',
    url VARCHAR(200) NOT NULL DEFAULT '',
    pid INT NOT NULL DEFAULT 0,
    sn VARCHAR(50) NOT NULL DEFAULT '',
    level INT NOT NULL DEFAULT 0
);
--模块表:数据时一种树形结构
-- 如:pid:1总公司
--        pid:2浙江分公司
--        pid:2北京分公司
--        pid:2上海分公司
--            pid:3余杭区子公司
--            pid:3西湖区子公司


#权限表
CREATE TABLE t_acl(
    aid INT PRIMARY KEY AUTO_INCREMENT,
    rid INT NOT NULL DEFAULT 0,
    mid INT NOT NULL DEFAULT 0,
    c ENUM('1','0') NOT NULL DEFAULT '0',
    r ENUM('1','0') NOT NULL DEFAULT '0',
    u ENUM('1','0') NOT NULL DEFAULT '0',
    d ENUM('1','0') NOT NULL DEFAULT '0'
    #FOREIGN KEY(rid) REFERENCES t_role(rid),
    #FOREIGN KEY(mid) REFERENCES t_module(mid)
);