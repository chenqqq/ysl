#ysl数据表
SET NAMES UTF8;
DROP DATABASE IF EXISTS YSL;
CREATE DATABASE YSL CHARSET=UTF8;
USE YSL;

#轮播 ysl_lunbo

CREATE TABLE ysl_lunbo(
  cid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(128) DEFAULT '',
  title VARCHAR(64)
);

#轮播
INSERT INTO ysl_lunbo VALUES (null, 'images/banner/banner1.jpg', '轮播广告商品1');
INSERT INTO ysl_lunbo VALUES (NULL, 'images/banner/banner2.jpg', '轮播广告商品2');
INSERT INTO ysl_lunbo VALUES (NULL, 'images/banner/banner3.jpg', '轮播广告商品3');

#明星产品 mingx
CREATE TABLE ysl_mingx(
  cid INT(11) PRIMARY KEY AUTO_INCREMENT,
    img VARCHAR(128) DEFAULT '',
    title VARCHAR(64) DEFAULT '',
    wen   VARCHAR(128) DEFAULT ''     
);

INSERT INTO ysl_mingx VALUES ('1', 'images/wthree_services/wthree_services1.jpg', '图1','未来新肌 时间，就是现在' );
INSERT INTO ysl_mingx VALUES ('2', 'images/wthree_services/wthree_services2.jpg', '图2', '未来新肌 时间，就是现在' );
INSERT INTO ysl_mingx VALUES ('3', 'images/wthree_services/wthree_services3.jpg', '图3', '未来新肌 时间，就是现在' );
INSERT INTO ysl_mingx VALUES ('4', 'images/wthree_services/wthree_services4.jpg', '图4', '未来新肌 时间，就是现在' );
INSERT INTO ysl_mingx VALUES ('5', 'images/wthree_services/wthree_services5.jpg', '图5','未来新肌 时间，就是现在' );
INSERT INTO ysl_mingx VALUES ('6', 'images/wthree_services/wthree_services6.jpg', '图6', '未来新肌 时间，就是现在' );
#分类

CREATE TABLE ysl_page(
    fid INT(11) PRIMARY KEY AUTO_INCREMENT,
    fname  VARCHAR(32)  
);

INSERT INTO ysl_page VALUES (1, '护肤' );
INSERT INTO ysl_page VALUES (2, '口红' );
INSERT INTO ysl_page VALUES (3, '香水' );
CREATE TABLE ysl_laptop_pic(
  pid INT PRIMARY KEY AUTO_INCREMENT,
  laptop_id INT,              #编号
  sm VARCHAR(128),            #小图片路径
  md VARCHAR(128),            #中图片路径
  lg VARCHAR(128)             #大图片路径
);
#商品表
CREATE TABLE ysl_product(
    pid INT(11) PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(64) DEFAULT '',
    fid INT(11),			#商品FID注意和分类的FID一致
    FOREIGN KEY(fid) REFERENCES ysl_page(fid),
    img VARCHAR(64) DEFAULT '',
    price DECIMAL(10,2) DEFAULT 99999.99,
    detail VARCHAR(512) DEFAULT ''
);
INSERT  INTO ysl_product  VALUES(null,'圣罗兰超模绝密亮肌露*' ,'1','img/plp_1.jpg','520','描述
1. 任意购物即可臻享随行礼
2. 首次购物，可享受新客入会三件礼
同时购买黑丝缎亮肌乳+丰唇露，即享眼唇卸妆乳30ml

【黑丝缎】
圣罗兰专为底妆用户打造的护肤品，媲美保湿精华的卓越保湿功效，更能平整肤质，打造拥有至高质感的“丝缎肌”。
创新“幻变爆水科技”让粉色凝露状“黑丝缎”在轻触瞬间幻化水感质地，尽享顺滑、滋润的涂抹体验；再推开，水分迅速被吸收，肌肤如同覆盖一层隐形黑丝缎，感受平滑、柔细的肌肤触感。
搭配使用圣罗兰亮颜双效按摩刷，打造清爽哑光/缎面高光两种肌底。

*圣罗兰亮颜亮肌露');                   
INSERT  INTO ysl_product  VALUES(null,'圣罗兰纯白乳液 50ml','1','img/plp_2.jpg','820','轻薄凝乳质地，蕴含GLYCO-BRIGHTTM COMPLEX
纯白科技以及天然植物保湿成分，给肌肤带来轻盈的润泽亮白无瑕。');                    
INSERT  INTO ysl_product  VALUES(null,'圣罗兰纯白精华液 30ml' ,'1','img/plp_3.jpg','920','清新水感质感，蕴含GLYCO-BRIGHTTM COMPLEX
纯白科技以及角质调理因子，帮助肌肤二次清洁，导入后续护肤成分。');                   
INSERT  INTO ysl_product  VALUES(null,'圣罗兰黑丝缎丰唇露*','1','img/plp_4.jpg','620','1. 任意购物即可臻享随行礼
2. 首次购物，可享受新客入会三件礼
同时购买黑丝缎亮肌乳+丰唇露，即享眼唇卸妆乳30ml

圣罗兰3合1护唇精华，集滋润，去角质，打底护色于一支黑金前卫精巧管身，随时随地，全天候打造如丝缎般亮滑的丰盈嘴唇，唇妆更持久，均匀，亮泽。

NUTRITION 滋润：修复干燥唇部，唇部水润，柔软，舒适，唇部边缘更为明显，唇形更为立体。
GENTLE PEEL 去角质：一天一天，柔和去除唇部死皮，唇纹逐渐平滑减少，唇妆打造更为均匀。
COLOR GLOW 打底护色：妆前使用，立显唇部自然唇色，透出健康光感，唇妆后使用，颜色更为持久 亮泽。');                    
INSERT  INTO ysl_product  VALUES(null,'圣罗兰新妍活青春精华液','1','img/plp_5.jpg','300','【天鹅瓶】
立体小脸，纤长美颈，紧致肩颈，YSL全新定义女性Y型轮廓！源自7项诺贝尔科技的聚糖科技，从肌肤的各个层面紧实提升肌肤；更有Glycan Y线条提升科技，从三个维度收紧肌肤，打造迷人的Y型脸庞颈部轮廓！YSL圣罗兰推出塑颜精华，富含Glycanactif Y™聚糖复合物以及红茶酵母复合物，发挥显著的提拉功效,有效重塑Y型轮廓。
使用7天后，肌肤倍感丰润饱满，光彩夺目。
使用1个月后，面部肌肤倍感紧致弹性，颈部周围紧实滋润。展现俏丽Y形轮廓。');                   
INSERT  INTO ysl_product  VALUES(null,'圣罗兰臻透亮白精华液'  ,'1','img/plp_6.jpg','1290','【明彩瓶】
优雅白色瓶身中，蕴藏丝缎般细致的晶亮剔透的凝露质地精华液，易吸收，令肌肤顷刻绽放前所未见的剔透亮光。使用时，清新优雅的木质花香，更令心情格外放松愉悦，给予肌肤无懈可击的密集亮泽、美白、紧致效能。含高浓度“臻透亮白复合物”同时作用于角质细胞，黑色素体与纤维母细胞，有效促进肌肤真皮层再造紧致，肌肤拥有足够的真皮支撑力，自然紧致饱满。

使用7天后，肌肤更具透明感，暗哑减退，肌肤绽放无可比拟的亮采。
1个月后，肌肤的瑕疵得到改善，色斑、毛孔、细纹和泛红位置有所减退，肤色更均匀。');
 


INSERT  INTO ysl_product  VALUES(null,'限量明星12支装口红礼盒','2','img/plp_7.jpg','820','礼盒包含：
夹心唇膏 #3（正品）
夹心唇膏 #4（正品）
夹心唇膏 #6（正品）
圆管唇膏 #49 （正品）
圆管唇膏 #14 （正品）
圆管唇膏#12（正品）
方管口红 #13 （正品）
方管口红 #52 （正品）
方管口红 #1 （正品）
纯色唇釉 #12 （正品）
黑管唇釉 #413 （正品）
水唇釉 #219 （正品）
反转巴黎女士香水 7.5ml
限量高级定制12支装包装礼盒');                    
INSERT  INTO ysl_product  VALUES(null,'圣罗兰黑管唇釉*' ,'2','img/plp_8.jpg','920','*圣罗兰纯色唇釉 
“全新YSL黑管唇釉，通过突破性的前沿科技，革命性地创造出YSL第一款胶质唇釉，注入先进持色科技和乳霜精华滋养因子，打造浓郁、完美显色的胶质闪耀双唇。”
胶质般闪耀，乳霜般舒适，黑胶般持久。鲜明大胆的色调，弥漫着危险、摇滚、叛逆的气息，一试成瘾。');                   
INSERT  INTO ysl_product  VALUES(null,'圣罗兰纯口红','2','img/plp_9.jpg','620','“红色是一种宣言，是存在的证明，是女性气质充满张力的演绎。”圣罗兰纯口红，真正为优雅美丽高级定制的口红！融合纯正色彩、耀眼光泽和滋润质地于一身，赋予双唇丝缎般细腻与浓郁的色泽质感。金色方管高定设计，如珠宝般纯粹高贵。无论是身穿优雅晚装或时尚便服，圣罗兰纯口红都能搭配不同形象，成为隐藏于手袋内的一个美妆法宝。');                    
INSERT  INTO ysl_product  VALUES(null,'圣罗兰莹亮纯魅唇膏','2','img/plp_10.jpg','300','天真烂漫的自由灵魂下，都隐藏着义无反顾的叛逆本能。YSL女孩们怀着炙热的心，勇于表达自我，敢于特立独行。一个莹亮清透的吻，如同一幅用双唇作出的画，持久而诱惑。炫丽，盈润的色彩让你释放最真实的自我，肆意展现个性和美。
YSL夹心唇膏，运用温热导入和双色灌装技术，设计出开创性混合配方唇膏，引领裸妆风潮，12种清新色彩，3个系列色调组合，衬托你内心的个性一面。');                   
INSERT  INTO ysl_product  VALUES(null,'限量全明星48支装口红礼盒'  ,'2','img/plp_11.jpg','1290','礼盒包含：
方管口红 #9 
方管口红 #13 
方管口红 #17 
方管口红 #19 
方管口红 #23 
方管口红 #36 
方管口红 #52 
方管口红 #207 
方管口红 #208 
方管口红 #211 
方管口红 #213 
方管口红 #215 
水唇釉 #202 
水唇釉 #204 
水唇釉 #219 
水唇釉 #220 
纯色唇釉 #9 
纯色唇釉 #12 
纯色唇釉 #46 
纯色唇釉 #50 
黑管唇釉 #401 
黑管唇釉 #402 
黑管唇釉 #413 
黑管唇釉 #415 
圆管唇膏 #4 
圆管唇膏 #5 
圆管唇膏 #12 
圆管唇膏 #13 
圆管唇膏 #14 
圆管唇膏 #15 
圆管唇膏 #41 
圆管唇膏 #45 
圆管唇膏 #46 
圆管唇膏 #49 
圆管唇膏 #50 
圆管唇膏 #52 
夹心唇膏 #1 
夹心唇膏 #2 
夹心唇膏 #3 
夹心唇膏 #4 
夹心唇膏 #5 
夹心唇膏 #6 
夹心唇膏 #7 
夹心唇膏 #8 
夹心唇膏 #9 
夹心唇膏 #10 
夹心唇膏 #11 
夹心唇膏 #12 
48支口红包装盒');
INSERT  INTO ysl_product  VALUES(null,'圣罗兰甜吻唇颊霜' ,'2','img/plp_12.jpg','520','YSL圣罗兰甜吻唇颊霜以“KISS YOUR CHEEKS, BLUSH YOUR LIPS 上一秒轻吻，下一秒红晕”为概念,融合唇膏与粉底两大科技,唇颊两用。轻盈慕斯质地，一抹幻化天鹅绒质感，轻松打造哑亮妆效。独特“灵动珍珠刷头”，精准用量，均匀上色。YSL色彩宣言，同系Match-Match和撞色Mix-Match，无限叠加，随心搭配。');        




INSERT  INTO ysl_product  VALUES(null,'圣罗兰天之骄子运动男士淡香水','3','img/plp_13.jpg','820','伊夫•圣罗兰为其传奇香氛系列推出又一全新成员，而唯有这一名字，方能彰显其阳刚洒脱：伊夫•圣罗兰L’HOMME SPORT男士香水。永恒经典的玻璃瓶身轮廓和无与伦比的金属瓶盖设计，伊夫•圣罗兰L’HOMME 男士香水为男士气概做出全新演绎。磁性魅力。性感非凡。刚劲有力。这款至尊香氛于2006年一经推出，便奠定其全新香氛风格：清新的木香香调。大胆混合柑橘香调与岩兰草芬芳，清冷跃动的雪松与紫罗兰叶香调中散发出的果味香浓和绿叶清香相融合，奠定了L’HOMME香水的迷人风尚。8年来，由Anne Flipo， Dominique Ropion和Pierre Wargnye (IFF)共同研制的这款香水，更增添了一抹阳刚式优雅。一款停驻光阴，用心关注识香人的香氛。');                    
INSERT  INTO ysl_product  VALUES(null,'圣罗兰天之骄子男士古龙水' ,'3','img/plp_14.jpg','920','圣罗兰天之骄子古龙水散发着现代木质气息的果感清新，展现出磁性魅力的男士气概，是绅士适用的经典香氛。刻有至尊YSL Cassandra徽标的厚重瓶盖、轮廓的刚劲有力与玻璃香水瓶的纯净线条相得益彰。');                   
INSERT  INTO ysl_product  VALUES(null,'圣罗兰奥飘茗情迷女士香水','3','img/plp_15.jpg','620','“鸦片（OPIUM英文意为鸦片），魔法的字眼，意义非凡的字眼，带你走入最隐秘神奇的梦境，是开启梦想的大门……”——伊夫•圣•罗兰
全新柔嫩粉色香水瓶身一改经典颜色，晶莹透现尤如神话，融汇女性柔美与性感，既把握当下，又稍纵即逝。');                    
INSERT  INTO ysl_product  VALUES(null,'圣罗兰巴黎香水','3','img/plp_16.jpg','300','“这款新香水，我选择以你命名，因为你们都美到极致，无可比拟。因为我爱你，巴黎。”——伊夫•圣•罗兰
巴黎女士系列香水设计于1983年，浓缩品牌之精华，将伊夫•圣•罗兰对巴黎这座五光十色之城的倾心爱慕，全部盛载在小小的透明香水瓶中。钻石切割面的瓶身绚烂夺目仿若精彩绝伦的巴黎。');                   
INSERT  INTO ysl_product  VALUES(null,'圣罗兰巴黎女士淡香水'  ,'3','img/plp_17.jpg','1290','这款新香水，我选择以你命名，因为你们都美到极致，无可比拟。因为我爱你，巴黎。”——伊夫•圣•罗兰
本款香水浓缩品牌之精华，因伊夫•圣•罗兰想把巴黎的神采意韵，将对这座五光十色之城的倾心爱慕，全部盛载在小小的透明香水瓶中。钻石切割面的瓶身绚烂夺目仿若精彩绝伦的巴黎
巴黎女士系列香水设计于1983年。献给那些天性对玫瑰花有着感性触觉的女性；同时，它也像一束精美的花束，献给世界上浪漫而美丽的城市——巴黎。以一种富有感情的现代精神表现的浪漫主义，这就是1995年“巴黎”香水带给人们的新气息。');
INSERT  INTO ysl_product  VALUES(null,'圣罗兰黑鸦片淡香水*'  ,'3','img/plp_18.jpg','1290','圣罗兰美妆隆重出品黑色奥飘茗女士淡香水。它与黑色奥飘茗女士浓香水不同，闪耀个性风格，创造独有气息，令人沉醉。前调是绿橘，犹如刚新鲜采摘下的干净橘子，清新活力。中调是明亮柔美的橙花夹杂一丝优雅的茉莉。后调是咖啡香调，浓郁而让人沉醉。瞬间脱颖而出，瞬间魅力动人。
*圣罗兰黑色奥飘茗女士淡香水');

#购物车表
CREATE TABLE ysl_user(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(32),
  upwd VARCHAR(32),
  email VARCHAR(64),
  phone VARCHAR(16),
  avatar VARCHAR(128),        #头像图片路径
  user_name VARCHAR(32),      #用户名，如王小明
  gender INT                  #性别  0-女  1-男
  );
/**收货地址信息**/
CREATE TABLE ysl_receiver_address(
  aid INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,                #用户编号
  receiver VARCHAR(16),       #接收人姓名
  province VARCHAR(16),       #省
  city VARCHAR(16),           #市
  county VARCHAR(16),         #县
  address VARCHAR(128),       #详细地址
  cellphone VARCHAR(16),      #手机
  fixedphone VARCHAR(16),     #固定电话
  postcode CHAR(6),           #邮编
  tag VARCHAR(16),            #标签名

  is_default BOOLEAN          #是否为当前用户的默认收货地址
);
/**购物车条目**/
CREATE TABLE ysl_shoppingcart_item(
  iid INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,      #用户编号
  product_id INT,   #商品编号
  count INT,        #购买数量
  is_checked BOOLEAN #是否已勾选，确定购买
);

/**用户订单**/
CREATE TABLE ysl_order(
  aid INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  address_id INT,
  status INT,             #订单状态  1-等待付款  2-等待发货  3-运输中  4-已签收  5-已取消
  order_time BIGINT,      #下单时间
  pay_time BIGINT,        #付款时间
  deliver_time BIGINT,    #发货时间
  received_time BIGINT    #签收时间
)AUTO_INCREMENT=10000000;

/**用户订单**/
CREATE TABLE ysl_order_detail(
  did INT PRIMARY KEY AUTO_INCREMENT,
  order_id INT,           #订单编号
  product_id INT,         #产品编号
  count INT               #购买数量
);
INSERT INTO ysl_user VALUES
(NULL, 'dingding', '123456', 'ding@qq.com', '13501234567', 'img/avatar/default.png', '清明', '1'),
(NULL, 'dangdang', '123456', 'dang@qq.com', '13501234568', 'img/avatar/default.png', '河图', '1'),
(NULL, 'doudou', '123456', 'dou@qq.com', '13501234569', 'img/avatar/default.png', '锄禾', '1'),
(NULL, 'yaya', '123456', 'ya@qq.com', '13501234560', 'img/avatar/default.png', '当午', '0');


