
var lBtn=document.getElementById('lBtn');

console.log(lBtn)
lBtn.onclick=function(e){
    e.preventDefault();
    var uname=document.querySelector("#lForm>div:nth-child(1)>input").value;
    var upwd=document.querySelector("#lForm>div:nth-child(2)>input").value;
    console.log(uname,upwd);
    ajax({
        type:"post",
        url:"data/user/login.php",
        data:`uname=${uname}&upwd=${upwd}`,
        dataType:"json"
    }).then((data)=>{
        alert(data.msg);
        location.href="YSL.html";
    })
}


// function uname_focus(){
//     //在 uname-show 中提示 用户名称6-18位
//     uname.innerHTML="用户名称6-18位";
// }

// function uname_blur(){
//     //1、先获取 uname 的 值(value)
//     let name = document.querySelector("#lForm>div:nth-child(1)>input").value;
//     //2、判断是否为空，并给出提示
//     if(name==""){
//         uname.innerHTML = "用户名称不能为空";
//         return;
//     }else{
//         $.ajax({
//                 type:"get",
//                 url:"data/user/check_uname.php",
//                 data:{uname:name},
//                 success:function (data) {
//                     uname.innerHTML=data.msg;
//             },
//             error:function () {
//             alert("网络故障，请检查");
//             }
//          });
//         }
// }
// function upwd_focus(){
//     upwd.innerHTML="用户密码6-18位";
// }
// function upwd_blur(){
//     let pwd = document.querySelector("#lForm>div:nth-child(2)>input").value;
//     //2、判断是否为空，并给出提示
//     if(pwd==""){
//         upwd.innerHTML = "密码不能为空";
//     }else{
//         upwd.innerHTML="";
//     }
// }
//     