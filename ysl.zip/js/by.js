$(".by").animate({
        opacity:0
    },6000,function(){
        $(this).hide()
    });
    $(".by").click(function(){
      $(this).hide();  
    })