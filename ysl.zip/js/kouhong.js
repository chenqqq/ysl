(()=>{
    ajax({
        type:"get",
        url:"data/pages.php",
        dataType:"json"
    }).then(data=>{
        var a=data;
        console.log(a);
        var html="";
        var panel=document.querySelector(".panel");
        console.log(panel);
        html+=`<div class="plp-baner">
            <img src="img/K_rouge.jpg" alt="">
            <div class="plp-text">
              <h2>口红<br> SKINCARE</h2>
              <p>拒绝妥协</p>
            </div>
        </div>`;
        for(var i=6;i<8;i++){
            var item=data[i];
            html+=`<div class="plp-wrapper">
            <img src="${item.img}" height="319" width="227">
            <div class="product_name">
              <span>${item.title}</span>
              <img src="img/plp.png" alt="">
              <span>￥${item.price}</span>
              <a href="page_products.html?pid=${item.pid}">直接购买</a>
            </div>
        </div>`
        }
        for(var i=8;i<=11;i++){
            var item=data[i];
            html+=`<div class="wrapper">
          <img src="${item.img}" height="319" width="227">
          <div class="product">
            <span>${item.title}</span>
            <img src="img/plp.png" alt="">
            <span>￥${item.price}</span>
            <a href="page_products.html?pid=${item.pid}">直接购买</a>
          </div>
        </div>`    
        }
        panel.innerHTML=html;
    })
})()