/* 
* @Author: anchen
* @Date:   2017-12-21 13:16:32
* @Last Modified by:   anchen
* @Last Modified time: 2018-01-26 20:58:48
*/

/**
*验证用户名,邮箱,密码，验证码是否符合条件,全部输入正确后成功注册
*/
$((()=>{
    let result=true;
    let $box=$("#c-box");
    const NUM=4;
    let chenqin=0;
    /**
    *用于需要向数据库发送异步请求检验是否存在的验证
    */
    function vali($txt,url,isNull,isExists,reg,msg1){
        return new Promise(resolve=>{
            let $p=$txt.next();
            if($txt.val()==""){
                getStyle($p,"right","error",isNull);
                result=false;
            }else{
                if(!reg.test($txt.val())){
                    getStyle($p,"right","error",msg1)
                    result=false;
                }else{
                    $.get(url,`${$txt.attr("name")}=${$txt.val()}`)
                        .then(data=>{      
                            if(data.code==200){
                                getStyle($p,"error","right","通过");
                                chenqin+=5;
                                console.log(chenqin)
                                result=true;
                                resolve();
                            }else{
                                getStyle($p,"right","error",isExists)
                                result=false;
                            }
                        })
                }
            }
        });
    }
    /*
    *检验用户名
    */
    $("input[name=uname]").blur(function(){
        vali($(this),"data/user/check_uname.php","用户名不能为空","用户名已经存在",
            /^\w{6,16}$/,"用户名格式错误");
        
    });
    
    /**
    *用于检验两次密码是否输入一致
    */
    function checkPwd(){
        let $upwd=$("input[name=upwd]");
        let $cpwd=$("input[name=cpwd]");
        let $p=$cpwd.next();
        if($upwd.val()==""){
            getStyle($upwd.next(),"right","error","密码不能为空");
            result=false;
        }else{
            if($cpwd.val()==""){
                getStyle($p,"right","error","请确认密码");
                result=false;
            }else if($upwd.val()!=$cpwd.val()){
                getStyle($p,"right","error","两次输入不一致");
                result=false;
            }else{
                getStyle($p,"error","right","通过");
                chenqin+=5;
                console.log(chenqin)
                result=true;
            }
        }
    }


    /**
    *检验邮箱
    */
    $("input[name=email]").blur(e=>{
        vali($(e.target),"data/user/check_email.php","邮箱不能为空","邮箱已经存在",
            /^\w+@\w+.\w+$/,"邮箱格式错误");
        
    });
    
    /**
    *检验密码
    */
    $("input[name=upwd]").blur(e=>{
        let reg=/^\w{6,12}$/;
        let $upwd=$(e.target);
        let $p=$upwd.next();
        if($upwd.val()==""){
            getStyle($p,"right","error","密码不能为空");
            result=false;
        }else{
            if(reg.test($upwd.val())){
                getStyle($p,"error","right","通过");
                chenqin+=5;
                console.log(chenqin)
                result=true;
            }else{
                getStyle($p,"right","error","密码格式错误");
                result=false;
            }
        }
        
    });
    $("input[name=cpwd]").blur(e=>{
        if($(e.target).val()==""){
            getStyle($(e.target).next(),"right","error","请确认密码");
            result=false;
        }else{
            checkPwd();
        }
        
    });

    /**
    *生成验证码,随机生成样式并添加进入验证码框中
    */
    function getCode(n){
        $box.children().remove();
        let arr=[0,1,2,3,4,5,6,7,8,9,"a","b","c","d","e","f","g","h","i","j",
                            "k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"];
        let code=[];
        for(let i=0;i<n;i++){
            let num=Math.ceil(Math.random()*35);
            if(typeof arr[num] == "string"){
                Math.random()>0.5?arr[num]:(arr[num]=arr[num].toUpperCase());
            }           
            $("<span>"+arr[num]+"</span>").appendTo($box).css({
                "display":"inline-block",
                "color":rc(0,180),
                "transform":`skewY(${Math.random()>0.5?"-":""}${Math.ceil(Math.random()*45)}deg)`,
                "width":20,
                "height":30,
                "fontSize":20
            });     
        }
    }
    getCode(NUM);

    /*
    * 生成一个指定范围内的随机数
    */
    function rn(min,max){
        return Math.floor(Math.random()*(max-min)+min);
    }

    /**
     *生成指定范围内随机颜色
     */
    function rc(min,max){
        let r=rn(min,max);
        let g=rn(min,max);
        let b=rn(min,max);
        return `rgb(${r},${g},${b})`;
    }

    /**
    *点击切换验证码并改变背景颜色
    */
    $box.click(e=>{ 
        getCode(NUM);
        $box.css("background",rc(180,230));
    });

    /**
    *点击验证码框显示验证码
    */
    $("input[name=c-code]").click(e=>{
        $box.css("opacity",1);
    });
    
    /**
    *检验验证码是否输入正确
    */
    function checkCode(){
        let $code=$("input[name=c-code]");
        let $box=$code.next();
        let $span=$code.next().next();
        // console.log($box.text());
        if($code.val()==""){
            getStyle($span,"right","error","请输入验证码");
            result=false;
        }else{
            if($code.val().toUpperCase()==$box.text().toUpperCase()){
                getStyle($span,"error","right","通过");
                chenqin+=5;
                console.log(chenqin)
                result=true;
            }else{
                getStyle($span,"right","error","输入错误,请重新输入");
                result=false;
                getCode(NUM);
            }
        }

    }

    /**
    *检验验证码
    */
    $("input[name=c-code]").blur(e=>{
        checkCode();
        
    });

    /**
    *将添加判断对错的样式单独封装为一个函数
    */
    function getStyle($elem,class1,class2,msg){
        $elem.removeClass(class1).addClass(class2).text(msg);
    }
    
    /**
    *注册提交,应该在邮箱和用户名的异步请求结束后才能提交
    */
    $("#rForm").submit(e=>{
        e.preventDefault(); 
        Promise.all([
            vali($("input[name=uname]"),"data/user/check_uname.php","用户名不能为空","用户名已经存在",
            /^\w{6,16}$/,"用户名格式错误")
            ,
            vali($("input[name=email]"),"data/user/check_email.php","邮箱不能为空","邮箱已经存在",
            /^\w+@\w+.\w+$/,"邮箱格式错误")
        ]).then(()=>{
                checkPwd();
                checkCode();
                if(result){
                    $.post("data/user/register.php",$("#rForm").serialize())
                        .then(data=>{
                            if(data.code==200){
                                alert("注册成功");
                            }
                        })
                }
            })
    });

    
})());
