$(()=>{
   

    function load(){
    $.ajax({
        url:'data/cart/list.php',
        success:function(result){
            //console.log(result)
            if(result.code==200){
                var html = '';
                var sum = 0;//总价
                var count = 0; //已选商品数
                $.each(result.data, function(index, item) {
                     /* iterate through array or object */
                    
                     if(item.is_checked==1){
                         count++;
                         sum+=item.price * item.count;
                        
                     }
              
                html+= `<div class="imfor">
                    <div class="check">
                        <div class="Each">
                            <span class="${item.is_checked==0?'normal':'true'}">
                              <img src="${item.is_checked==0?'img/product_normal.png':'img/product_true.png'}" height="12" width="12" alt="" />
                              <input type="hidden" name="id" value="20" />
                            </span>
                        </div>
                    </div>
                    <div class="pudc">
                        <div class="pudc_information">
                            <a href="page_products.html?lid=${item.lid}">
                              <img src="${item.img}" height="54" width="54" alt="" />
                            </a>
                            <input type="hidden" name value />
                            <span class="des if">
                                <a href="page_products.html?lid=${item.lid}">
                                ${item.title}
                                 </a>
                                <input type="hidden" name value />
                            </span>
                            
                        </div>
                    </div>
                    <div class="pices">
                        <p class="pices_des">今日优惠价</p>
                        <p class="pices_information"><b>￥</b>
                        <span>${item.price}</span>
                            <input type="hidden" name value />
                        </p>
                    </div>
                    <div class="num">
                        <span class="reduc">-</span>
                        <input type="text" value="${item.count}" />
                        <span class="add">+</span>
                    </div>
                    <div class="totle">
                        
                        <span class="totle_information">${item.price * item.count}</span>
                    </div>
                    <div class="del">
                      <a href="${item.iid}"  class="del_d">删除</a>
                    </div>
                  </div> `   ;
                
                });

            
            $('#content_box_body').html(html);
             $(".susum").text(sum.toFixed(2));
             $(".susumOne").text(sum.toFixed(2));
            $('.total').text(count);
              $('.totalOne').text(count);
              if(count ===result.data.length){
                  console.log(1);
                if ($('.all>span').hasClass('normal')) {
                    $('.all>span').addClass('true').removeClass('normal');
                    $('.all>span>img').attr('src', 'img/product_true.png');
                }
              }
            
            }
        },
        error(){
          console.log(1)
      }

    })
}
load();
///绑定全选
$(".all").click(function () {
    // amountadd();
    if ($('.all>span').hasClass('normal')) {
       
    //   $(".Each>span").each(function () {
    //     $(this).addClass('true').removeClass('normal');
    //     $(this).children('img').attr('src', 'img/product_true.png');
    //   })
        $.ajax({
            url:'data/cart/selectAll.php',
            data:{checked:1},
            success(){
                $('.all>span').addClass('true').removeClass('normal');
                $('.all>span>img').attr('src', 'img/product_true.png');
                load();
                
    
            },
            error(){
                alert('网络故障')
            }
        })
    //   totl();
    } else {
       $('.all>span').addClass('normal').removeClass('true');
       $('.all>span>img').attr('src', 'img/product_normal.png');
    //   $('.Each>span').addClass('normal').removeClass('true');
    //   $('.Each>span>img').attr('src', 'img/product_normal.png');
       $(".susum").text(0.00);
       $(".susumOne").text(0.00);
       $('.total').text(0);
      $('.totalOne').text(0);
    $.ajax({
        url:'data/cart/selectAll.php',
        data:{checked:0},
        success(){
            load();
        }
    })
    }
  })
//删除单条
  $('#content_box_body').on('click', '.del_d', (function (e) {
    e.preventDefault();
    var me = this;
    var id = $(this).attr('href');
    console.log(id)
    $('.modal').fadeIn();
    $('.no').click(function () {
      $('.modal').fadeOut();
    });
    $('.yes').click(function () {
      $.ajax({
        type: "POST",
        url: "data/cart/del.php",
        data: {iid: id},
        success: function (result) {
          console.log(result);
          $('.modal').fadeOut();
          if(result.code==200){
            $(me).parent().parent().remove();
          }else {
            alert('<b>删除失败！</b><p>错误原因为：'+result.msg+'</p>')
          }
        }
      });
    })
  }));


  //小计和加减
  //加
  $("#content_box_body").on('click', '.add', (function (e) {
    e.preventDefault();
    let num = parseInt($(this).prev().val());
    num+=1;
    let iid=$(this).parent().siblings('.del').children('a').attr('href');

    
    $.ajax({
      type: "post",
      url: "data/cart/update_count.php",
      data: {iid: iid, count: num},
      success: function (data) {
        console.log(data);
      }
    });
    load();
  }));

  $("#content_box_body").on('click','.reduc',(function(e){
    e.preventDefault();
    let num = parseInt($(this).next().val());
    let iid=$(this).parent().siblings('.del').children('a').attr('href');
     num-=1;
     if(num<1){
      $('.modal').fadeIn();
      $('.no').click(function () {
        $('.modal').fadeOut();
      });
      num=1;
      $('.yes').click(function () {
        $.ajax({
          type: "POST",
          url: "data/cart/del.php",
          data: {iid: iid},
          success: function (result) {
            console.log(result);
            $('.modal').fadeOut();
            if(result.code==200){
              $(this).parent().parent().remove();
            }else {
              alert('<b>删除失败！</b><p>错误原因为：'+result.msg+'</p>')
            }
            load();
          }
        });
      })
    }
    

     $.ajax({
      type: "post",
      url: "data/cart/update_count.php",
      data: {iid: iid, count: num},
      success: function (data) {
        console.log(data);
      }
    });
    load();
  }));


})

