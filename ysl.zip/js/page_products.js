(()=>{
    var pid=location.search.split("=")[1];
    ajax({
        type:"get",
        url:"data/page.php",
        data:"pid="+pid,
        dataType:"json"
    }).then(data=>{
         console.log(data);
        var html="";
        var subtitle = document.querySelector(".pdp_top h2");
        subtitle.innerHTML=data.title;
        var tab_details=document.querySelector(".tab_details");
        tab_details.innerHTML=data.detail;
        var mousetrap = document.querySelector(".mousetrap");
        mousetrap.innerHTML=`<img src="${data.img}" height="444" width="336" alt="">
                <div class="bigImage" style="background-image:url(${data.img})"></div>    //放大镜 放大后的图片容器
                <div class="supermaker" ></div>  //放大镜 遮罩层用于绑定事件
        `;
        var product_swatches=document.querySelector(".product_swatches");
        product_swatches.innerHTML = `<li>
                       <a href="">
                           <img src="${data.img}" alt="">
                       </a>
                   </li>`;
        var quantity =document.querySelector(".quantity>p");
        quantity.innerHTML="价格:¥"+data.price;


        //放大镜效果 start
         var supermaker = document.querySelector('.supermaker') ;  
         var bigImage   = document.querySelector('.bigImage');   
         supermaker.onmousemove=(e)=>{
            bigImage.style.display='block';
            var offsetX=e.offsetX*1.8;
            var offsetY=e.offsetY*1.8;

            bigImage.style.backgroundPosition=`-${offsetX}px -${offsetY}px`; 
        
         }
         supermaker.onmouseout=()=>{
             bigImage.style.display='none';
         }  
        //放大镜效果 end
    })
})()
