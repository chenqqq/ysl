$("body").on('click',"#show_engraving",function(e){
    e.preventDefault();
    var  butCount =parseInt($(".quantity_dropdown").val());
    var product_id=location.search.split('=')[1];
    console.log(product_id,butCount)
    // console.log(1)
    $.ajax({
        type:'post',
        url:'data/cart/addcart.php',
        data:{product_id:product_id,count:butCount},
        success:function(result){
            console.log(result)
            if(result.code == 300) {
                alert('您尚未登录!');
                location.href='login.html';
            }else if(result.code==200){
                alert('添加成功!');
                location.href = 'cart.html'
            }else{
                alert('<b添加失败！</b><p>错误原因为:'+result.msg+'</p>');
            }
        },
        err:function(){
            alert('网络故障,请检查')
        }
    })
})