/* 
* @Author: anchen
* @Date:   2018-01-11 13:38:20
* @Last Modified by:   anchen
* @Last Modified time: 2018-01-11 13:39:00
*/

(()=>{
 ajax({
    type:"get",
    url:"footer.html"
 }).then(html=>{
    document.getElementById("footer").innerHTML=html;
    });
 })();