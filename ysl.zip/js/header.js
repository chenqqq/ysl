/* 
* @Author: anchen
* @Date:   2018-01-06 14:21:40
* @Last Modified by:   anchen
* @Last Modified time: 2018-01-30 09:52:37
*/
(()=>{
ajax({
    type:"get",
    url:"header.html"
 }).then(html=>{
    document.getElementById("header").innerHTML=html;
    
    var loginList=document.getElementById("loginList"),
    welcomeList=document.getElementById("welcomeList"),
    uname=document.getElementById("uname");
        ajax({
            type:"get",
            url:"data/user/islogin.php",
            dataType:"json"
        }).then((data)=>{
            console.log(data)
            // data:{ok:0}或{ok:1,uname:yaya}
            if(data.ok==0){
                loginList.style.display="block";
                welcomeList.style.display="none";
            }else{
                loginList.style.display="none";
                welcomeList.style.display="block";
                uname.innerHTML=data.uname;
            }
        })



        document.getElementById("btnLogin").onclick=e=>{
            e.preventDefault();
            ajax({
                type:"get",
                url:"data/user/loginout.php"
            }).then((data)=>{
                // location.reload(true)
                console.log(data)
                location.href="YSL.html";
            })
        }
        
        // var aSearch=document.querySelector("#text-search>[data-trigger=search]");
        // txtSearch =document.getElementById("text-search");
        // aSearch.onclick=e=>{
        //     e.preventDefault();
        //     location="Perfume.html?kw="+txtSearch.value.trim();
        //     if(txtSearch.value.trim()!=="")
        // }
        // if(location.search.indexOf(("kw")!=-1){
        //     txtSearch.value =decodeURI(location.search.split("=")[1]
        //     ); 
        // }




    })
 })();