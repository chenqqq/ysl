/* 
* @Author: anchen
* @Date:   2018-01-20 11:31:53
* @Last Modified by:   anchen
* @Last Modified time: 2018-02-01 12:03:32
*/

(()=>{
    ajax({
        type:"get",
        url:"data/pages.php",
        dataType:"json"
    }).then(data=>{
        var a=data;
        console.log(a);
        var html="";
        var panel=document.querySelector(".panel");
        console.log(panel);
        html+=`<div class="plp-baner">
            <img src="img/OR_ROGUE.jpg" alt="">
            <div class="plp-text">
              <h2>护肤<br> SKINCARE</h2>
              <p>悦享生命</p>
            </div>
        </div>`;
        for(var i=0;i<2;i++){
            var item=data[i];
            html+=`<div class="plp-wrapper">
            <img src="${item.img}" height="319" width="227">
            <div class="product_name">
              <span>${item.title}</span>
              <img src="img/plp.png" alt="">
              <span>￥${item.price}</span>
              <a href="page_products.html?pid=${item.pid}">直接购买</a>
            </div>
        </div>`
        }
        for(var i=2;i<6;i++){
            var item=data[i];
            html+=`<div class="wrapper">
          <img src="${item.img}" height="319" width="227">
          <div class="product">
            <span>${item.title}</span>
            <img src="img/plp.png" alt="">
            <span>￥${item.price}</span>
            <a href="page_products.html?pid=${item.pid}">直接购买</a>
          </div>
        </div>`    
        }
        panel.innerHTML=html;
    })
})()