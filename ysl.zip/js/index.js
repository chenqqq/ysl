 /*banner3的滚动条*/
  var n=0
	function move (){
		if(n>-1600){
			n=n-1
		}
		else{
			n=0
		}
		$(".banner3 ul").css("left",n)
		}
	var t1=setInterval(move,1000/60)
	$(".banner3 ul").mouseenter(                           
		function(){
			clearInterval(t1);
		}
	).mouseleave(
		function(){
			t1=setInterval(move,1000/60)
		}
	)
